"""
For VS 2022 debugging, use it as you wish.
"""